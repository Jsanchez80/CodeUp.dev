#Layla

A Stylish Coming Soon Template for your upcoming business. 

#Features

- Stylish Modern Design
- Full Screen Video Background
- Responsive layout
- Optimized Code & Content
- Sticky Menu
- Count Down Timer. Easily customizable.
- Clean Code
- Cross-browser Compatibility
- CSS3 Animations
- 100% Fully Customizable
- Google Fonts
- Built with HTML5 & CSS3
- Strong focus on Usability and UX
- CSS Framework - Bootstrap 3
- Ionicons Icon Integrated
- Clean and stylish UI
- Smooth CSS3 animation
- Well commented coding
- Easy to use
- It's Free!

#Screenshot


![Screenshot of Flusk]
(https://raw.githubusercontent.com/technext/layla/master/Layla.png)

#Demo Link
Check out the demo of Flusk responsive HTML template at (http://themewagon.com/demo/layla/)